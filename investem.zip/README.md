# inve-STEM

A clean web frontend for your multi-asset portfolio simulation.
Your original `simulation.py` is imported **unchanged** — this adds a browser UI
on top so anyone can pick tickers, tweak parameters, and see the results.

## File layout

```
montecarlo_app/
├── app.py              # Flask server (imports your script)
├── simulation.py       # YOUR ORIGINAL CODE — untouched
├── requirements.txt
├── templates/
│   └── index.html
└── static/
    ├── style.css
    └── app.js
```

## Setup

```bash
cd montecarlo_app
pip install -r requirements.txt
```

## Run

```bash
python app.py
```

Then open **http://127.0.0.1:5000** in your browser.

## How it works

1. Enter tickers and weights (or pick a preset: S&P+Dow, Big Tech, Defensive, Global Mix).
2. Pick dates, number of Monte Carlo paths, and optionally tweak advanced GARCH params.
3. Hit **Execute Simulation**. The backend:
   - calls `simulation.download_and_store(...)` to pull price history from Yahoo Finance,
   - calls `simulation.PortfolioSimulator(...).simulate()` to run the Monte Carlo,
   - renders two matplotlib charts plus a metric strip
     (Mean, VaR 95%, CVaR 95%, P(loss), best/worst, actual return).

## Notes

- Your script is imported as-is. If you edit `simulation.py`, restart `app.py`.
- First run takes a bit longer because `numba` JIT-compiles the GARCH loop.
- The simulation requires **historical price data before `start_date`** to fit GARCH,
  and **actual prices at and after `start_date`** to overlay the red "Actual Price" line.
